import argparse

import pandas as pd
import numpy as np
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

train_features = pd.read_csv("data\\Educ.csv")
# answers are in 'lnw' column
train_labels = train_features["lnw"]
# want need taht column since we set it to specaial variable
del train_features["lnw"]


X_train, X_test, Y_train, Y_test = train_test_split(
    train_features, train_labels, test_size=0.2)

num_of_models = 15  # num of models we will experiment on
performances = []

models = dir(linear_model)[:num_of_models]
models.remove("Hinge")
models.remove("Huber")

print("We will work with models below: ")
print(models)


def mean_squared_error(a, b):
    # function helps to give a score to model
    a = np.array(a)
    b = np.array(b)
    return np.sum(np.subtract(a, b)**2)


for i in range(1, num_of_models - 2):
    # iterating over all models specified
    model = getattr(linear_model, models[i])()

    model.fit(X_train, Y_train)

    ans = Y_test.to_numpy()

    pred = model.predict(X_test)

    performances.append(mean_squared_error(ans, pred))

# performances off all models : -
print(performances)

print()
best_model = models[np.array(performances).argmin()]

print("Best model was: " + str(best_model))
print("Best model's squared error is : " +
      str(np.array(performances).argmin()))


parser = argparse.ArgumentParser()

parser.add_argument('-input', type=str, required=True,
                    help="give a list of inputs")

args = parser.parse_args()


to_test = eval(args.input)

if len(to_test) != 4:
    print("Wrong input, try something like [1,2,4,3]")
else:
        # get the best model
    model = getattr(linear_model, best_model)()

    model.fit(X_train, Y_train)

    prediction = model.predict(np.array([to_test]))

    print("Prediction is - " + str(prediction))
